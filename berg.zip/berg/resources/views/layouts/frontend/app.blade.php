<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Laravel') }} || @yield('title')</title>

    <!-- fav icon -->
    <link href="{{ asset('asset/frontend/img/berg-logo.jpg') }}" rel="shortcut icon" type="image/png">
    <!-- Loader-->
    <link href="{{ asset('asset/frontend/css/loaders.min.css') }}" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="{{ asset('asset/frontend/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- font-awesome-css -->
    <link rel="stylesheet" href="{{ asset('asset/frontend/css/fontawesom.all.min.css') }}">
    <!-- Normalize-css -->
    <link rel="stylesheet" href="{{ asset('asset/frontend/css/normalize.min.css') }}">
    <!-- Main-css -->
    <link rel="stylesheet" href="{{ asset('asset/frontend/css/style.css') }}">
    @stack('css')
</head>
<body>
<!--header-->
@include('layouts.frontend.includes.header')

@yield('content')

<!-- Footer-->
@include('layouts.frontend.includes.footer')


<!-- Loader-->
<script src="{{ asset('asset/frontend/js/loaders.css.js') }}"></script>
<!--jquery file-->
<script src="{{ asset('asset/frontend/js/jquery.min.js') }}"></script>
<!--main js file-->
<script src="{{ asset('asset/frontend/js/index.js') }}"></script>
@stack('script')
</body>
</html>
