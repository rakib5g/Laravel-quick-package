<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(Storage::disk('public')->url('profile/'.Auth::user()->image)); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->name); ?></p>
                <p><?php echo e(Auth::user()->email); ?></p>
            </div>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">NAVIGATION</li>

            <?php if(Request::is('admin*')): ?>
                <li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fa fa-dashboard"></i> Dashboard
                        <span class="pull-right-container"> </span>
                    </a>
                </li>

                <li class="header">SYSTEM</li>

            <?php endif; ?>

        <!--FOR AUTHOR-->

            <?php if(Request::is('author*')): ?>
                <li class="<?php echo e(Request::is('author/dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('author.dashboard')); ?>">
                        <i class="fa fa-dashboard"></i> Dashboard
                        <span class="pull-right-container"> </span>
                    </a>
                </li>
                <li class="header">SYSTEM</li>
            <?php endif; ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>