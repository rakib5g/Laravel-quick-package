@extends('layouts.frontend.app')

@section('title', 'Home')

@push('css')
@endpush

@section('content')
    <!--Starts Home Image Section-->
    <section id="home-image" class="py-5 text-center text-light ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="home-article">
                        <h1 class="display-4 font-weight-bold mt-5 pt-5 ">Institutional services from a global leader in financial trading</h1>
                        <p class="lead font-weight-bold mt-5 mb-5 pb-5">Access exceptional liquidity, powerful technology and over 40 years’ trading expertise with IG – an innovative FTSE 250 company with a robust balance sheet</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End of Home Image Section-->

    <!--Starts Home Video Section-->
    <section id="video-section" class="py-5 text-center">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="video-wrapper mb-5">
                        <iframe class="img-fluid vdo-fluid" width="700" height="400"
                                src="https://www.youtube.com/embed/6T2Rbskz_aA?rel=0&amp;showinfo=0"
                                frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>

                        </iframe>
                    </div>
                </div>

                <div class="col-md-4">
                    <h1>Professional platforms and APIs</h1>
                    <p class="lead">Real-time data feeds, fast execution and award-winning trading technology, plus a suite of tools and services that can be combined to support your business for grow.</p>
                    <a href="#" class="btn btn-success">Read More</a>
                </div>
                <div class="col-md-4">
                    <h1>15,000+ markets, deep liquidity</h1>
                    <p class="lead">Equities, commodities, indices, forex and more, with leveraged or unleveraged share trading, plus access to exceptional liquidity from our unparalleled internal pools and multiple external venues.</p>
                    <a href="#" class="btn btn-success">Read More</a>
                </div>
                <div class="col-md-4">
                    <h1>Dedicated service from the experts</h1>
                    <p class="lead">One-to-one support from our specialist institutional desk, underpinned by our 40+ years of experience as a trusted, market-leading trading provider with a global presence.</p>
                    <a href="#" class="btn btn-success">Read More</a>
                </div>
            </div>
        </div>
    </section>
    <!--End of Home Video Section-->

    <!--Starts Contact-us Section-->
    <section id="contact" class="py-5 text-center">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <div class="home-article">
                        <h1 class="font-weight-bold">Contact us</h1>
                        <p class="lead font-weight-bold">Let us create a solution tailored for your needs. Get in touch with our London-based team by phone or email to discuss your objectives, or request a brochure.</p>
                    </div>
                </div>
                <div class="col-md-4 mt-2">
                    <a href="#" class="btn btn-outline-success btn-block font-weight-bold">+44 (0)20 7573 0219</a>
                </div>
                <div class="col-md-4 mt-2">
                    <a href="#" class="btn btn-outline-success btn-block font-weight-bold">institutional@ig.com</a>
                </div>
                <div class="col-md-4 mt-2">
                    <a href="#" class="btn btn-outline-success btn-block font-weight-bold">Request a brochure</a>
                </div>
            </div>
        </div>
    </section>
    <!--End of Contact-us Section-->
@endsection

@push('script')
@endpush