<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?> || <?php echo $__env->yieldContent('title'); ?></title>

    <!-- fav icon -->
    <link href="<?php echo e(asset('asset/frontend/img/berg-logo.jpg')); ?>" rel="shortcut icon" type="image/png">
    <!-- Loader-->
    <link href="<?php echo e(asset('asset/frontend/css/loaders.min.css')); ?>" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('asset/frontend/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- font-awesome-css -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/frontend/css/fontawesom.all.min.css')); ?>">
    <!-- Normalize-css -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/frontend/css/normalize.min.css')); ?>">
    <!-- Main-css -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/frontend/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
<!--header-->
<?php echo $__env->make('layouts.frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<!-- Footer-->
<?php echo $__env->make('layouts.frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Loader-->
<script src="<?php echo e(asset('asset/frontend/js/loaders.css.js')); ?>"></script>
<!--jquery file-->
<script src="<?php echo e(asset('asset/frontend/js/jquery.min.js')); ?>"></script>
<!--main js file-->
<script src="<?php echo e(asset('asset/frontend/js/index.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
