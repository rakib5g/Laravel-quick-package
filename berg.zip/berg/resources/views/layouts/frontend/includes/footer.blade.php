<!--Starts Fotter Section-->
<footer>
    <div class="container-fluid">
        <div class="row">

            <div class="footer-left col-md-6 col-sm-12 text-center">
                <ul>
                    <li><a href="#">Terms of Business</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Regulation </a></li>
                </ul>
            </div>
            <div class="footer-right col-md-6 col-sm-12 col-sm-12">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a></li>
                </ul>
            </div>
            <div class="center col-md-12">
                <p>
                    Copy right &copy; by Berg Finances. All right reserved.
                </p>
            </div>

        </div>
    </div>
</footer>
<!--End of Fotter Section-->

<!--Starts Return to Top -->
<a href="#" id="return-to-top"><i class="fas fa-chevron-up"></i></a>
<!--End of Return to Top -->