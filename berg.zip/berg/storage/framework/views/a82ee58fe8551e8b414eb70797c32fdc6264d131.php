<!--Starts Preloader-->
<div class="A">
    <div class="loader">
        <div class="loader-inner ball-pulse">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>
<!--End of Preloader-->

<!--Starts top Navbar-->
<section class="nav-top">
    <div class="container">
        <div class="logo">
            <ul class="social-icon inline-block">
                <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fas fa-envelope" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a></li>
            </ul>
            <div class="country dropdown inline-block">
                <i class="fa fa-globe" aria-hidden="true"></i> Language:
                <select name="one" class="dropdown-select">
                    <option value="">English</option>
                    <option value="1">Polish</option>
                </select>
            </div>
        </div>
        <nav class="site-nav">
            <ul>
                <li><a href="about-us.html">About Us</a></li>
                <li><a href="financial-planning.html">Financial Planing</a></li>
                <li><a href="investment.html">Investment</a></li>
            </ul>
        </nav>
        <div class="menu-toggle">
            <div class="hamburger"></div>
        </div>
    </div>
</section>
<!--End of top Navbar-->

<!--Starts Bottom Navbar-->
<section class="nav-bottom">
    <div class="container-bottom">
        <div class="logo-bottom">
            <a href=""><img src="<?php echo e(asset('asset/frontend/img/berg-logo.jpg')); ?>" alt=""></a>
        </div>
        <nav class="site-nav-bottom">
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="financial-academy.html">Financial Academy</a></li>
                <li><a href="courses.html">Online Courses</a></li>
                <li><a href="blog.html">Blog</a></li>
            </ul>
        </nav>
        <div class="menu-toggle-bottom">
            <div class="hamburger-bottom"></div>
        </div>
    </div>
</section>
<!--End of Bottom Navbar-->
